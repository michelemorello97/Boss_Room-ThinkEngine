using it.unical.mat.embasp.languages.datalog;

namespace it.unical.mat.parsers.datalog
{
    public interface IDatalogDataCollection
    {
        void AddMinimalModel(MinimalModel minimalModel);
    }
}