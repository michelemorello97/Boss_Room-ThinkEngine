namespace it.unical.mat.parsers.pddl
{
    public interface IPDDLDataCollection
    {
        void StoreAction(string action);
    }
}