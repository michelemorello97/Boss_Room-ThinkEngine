﻿namespace it.unical.mat.embasp.@base
{
    public interface ICallback
    {
        void Callback(Output o);
    }
}