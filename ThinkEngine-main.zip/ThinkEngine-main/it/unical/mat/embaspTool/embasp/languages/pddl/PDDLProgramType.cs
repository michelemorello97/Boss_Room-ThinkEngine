﻿namespace it.unical.mat.embasp.languages.pddl
{
    public enum PDDLProgramType
    {
        PROBLEM,
        DOMAIN
    }
}