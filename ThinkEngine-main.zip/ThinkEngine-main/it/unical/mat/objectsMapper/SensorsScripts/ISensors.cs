﻿using System.Collections.Generic;

namespace ThinkEngine
{
    public interface ISensors
    {
        List<Sensor> GetSensorsList();
    }
}