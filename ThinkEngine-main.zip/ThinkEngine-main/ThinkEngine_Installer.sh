rm "/Users/fabiobarrese/Desktop/ThinkEngine-main/ThinkEnginePlugin.zip"
mkdir "/Users/fabiobarrese/Desktop/ThinkEngine-main/ThinkEnginePlugin.zip"
cp -R "/Users/fabiobarrese/Desktop/ThinkEngine-main/bin/Debug/ThinkEnginePlugin" "/Users/fabiobarrese/Desktop/ThinkEngine-main/ThinkEnginePlugin.zip"